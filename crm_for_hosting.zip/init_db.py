#!/usr/bin/env python3
"""
Скрипт инициализации базы данных CRM системы
Создает все необходимые таблицы и роли
"""

from app import create_app, db
from models import User, Role

def init_database():
    """Инициализация базы данных"""
    app = create_app()
    
    with app.app_context():
        print("Создание таблиц базы данных...")
        db.create_all()
        
        print("Создание ролей...")
        # Создаем роли если их нет
        roles_data = [
            ('director', 'Директор'),
            ('manager', 'Менеджер'),
            ('supplier', 'Поставщик'),
            ('warehouse', 'Склад'),
            ('production', 'Производство'),
            ('accountant', 'Бухгалтер')
        ]
        
        for role_name, description in roles_data:
            existing_role = Role.query.filter_by(name=role_name).first()
            if not existing_role:
                role = Role(name=role_name, description=description)
                db.session.add(role)
                print(f"Создана роль: {role_name}")
            else:
                print(f"Роль уже существует: {role_name}")
        
        db.session.commit()
        print("База данных инициализирована успешно!")

if __name__ == '__main__':
    init_database()
