#!/usr/bin/env python3
"""
Скрипт создания администратора CRM системы
Создает только директора с логином director и паролем password
"""

from app import create_app, db
from models import User, Role

def create_admin():
    """Создание администратора"""
    app = create_app()
    
    with app.app_context():
        print("Создание администратора...")
        
        # Проверяем, есть ли уже директор
        existing_director = User.query.filter_by(username='director').first()
        if existing_director:
            print("Директор уже существует")
            return
        
        # Создаем директора
        director = User(
            username='director',
            email='director@teploresurscrm.uz',
            first_name='Директор',
            last_name='Системы',
            phone='+998901234567'
        )
        director.set_password('password')
        
        # Добавляем роль директора
        director_role = Role.query.filter_by(name='director').first()
        if director_role:
            director.roles.append(director_role)
        
        db.session.add(director)
        db.session.commit()
        
        print("Директор создан успешно!")
        print("Данные для входа:")
        print("   Логин: director")
        print("   Пароль: password")
        print("ВАЖНО: Измените пароль после первого входа!")

if __name__ == '__main__':
    create_admin()
