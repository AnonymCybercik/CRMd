# Инструкция по развертыванию CRM системы

## Шаг 1: Загрузка файлов
1. Загрузите ZIP файл на сервер через панель управления хостингом
2. Распакуйте архив в корневую папку домена (обычно `public_html`)

## Шаг 2: Создание базы данных MySQL
1. В панели управления найдите раздел "Базы данных" или "MySQL"
2. Создайте новую базу данных: `teploresurscrm_db`
3. Создайте пользователя: `teploresurscrm_user`
4. Установите пароль: `KYm-yTb-mcn-eSH`
5. Назначьте пользователя к базе данных с полными правами

## Шаг 3: Настройка Python приложения
1. В панели управления найдите раздел "Python" или "Приложения"
2. Создайте новое Python приложение
3. Укажите:
   - **Корневая папка**: `public_html` (или путь к вашим файлам)
   - **Файл входа**: `wsgi.py`
   - **Точка входа**: `application`

## Шаг 4: Установка зависимостей
В терминале или через "Выполнить Python скрипт" выполните:
```bash
pip install -r requirements.txt
```

## Шаг 5: Инициализация базы данных
Выполните по порядку:
```bash
python init_db.py
python create_admin.py
python clear_database.py
```

## Шаг 6: Проверка работы
1. Откройте ваш сайт в браузере
2. Войдите с учетными данными:
   - **Логин**: director
   - **Пароль**: director123

## Возможные проблемы и решения

### Ошибка "ModuleNotFoundError: No module named 'MySQLdb'"
- Убедитесь, что в `config.py` используется `mysql+pymysql://` вместо `mysql://`

### Ошибка "Could not find a version that satisfies the requirement Werkzeug==3.1.3"
- В `requirements.txt` указана версия `Werkzeug==3.0.6`

### Ошибка "SyntaxError: invalid syntax" в wsgi.py
- Убедитесь, что файл `wsgi.py` содержит правильный код:
```python
from app import create_app
application = create_app()
if __name__ == "__main__":
    application.run()
```

### Ошибка "ImportError: cannot import name 'create_app'"
- Убедитесь, что файл `app.py` содержит функцию `create_app()`

## Структура файлов
- `app.py` - основное приложение Flask
- `models.py` - модели базы данных
- `config.py` - конфигурация (исправлен для PyMySQL)
- `wsgi.py` - точка входа для WSGI
- `passenger_wsgi.py` - альтернативная точка входа
- `requirements.txt` - зависимости Python
- `init_db.py` - инициализация базы данных
- `create_admin.py` - создание администратора
- `clear_database.py` - очистка тестовых данных
- `templates/` - HTML шаблоны
- `static/` - статические файлы (CSS, JS)

## Контакты поддержки
Если возникли проблемы, обратитесь к технической поддержке хостинга с описанием ошибки.
