#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from app import create_app
from models import db, User, Role
from werkzeug.security import generate_password_hash

def fix_passwords():
    """Исправление хеширования паролей"""
    app = create_app()
    
    with app.app_context():
        print("Исправление хеширования паролей...")
        
        try:
            # Получаем директора
            director = User.query.filter_by(username='director').first()
            
            if director:
                print("Обновление пароля директора...")
                # Устанавливаем новый пароль с правильным хешированием
                director.password_hash = generate_password_hash('director123')
                db.session.commit()
                print("Пароль директора обновлен!")
            else:
                print("Директор не найден, создаем заново...")
                # Создаем роли
                roles = ['director', 'manager', 'supplier', 'warehouse', 'production', 'accountant']
                for role_name in roles:
                    existing_role = Role.query.filter_by(name=role_name).first()
                    if not existing_role:
                        role = Role(name=role_name)
                        db.session.add(role)
                
                # Создаем директора
                director_role = Role.query.filter_by(name='director').first()
                director = User(
                    username='director',
                    email='director@teploresurscrm.uz',
                    first_name='Директор',
                    last_name='Компании'
                )
                director.set_password('director123')
                director.roles.append(director_role)
                db.session.add(director)
                db.session.commit()
                print("Директор создан!")
            
            print("Хеширование паролей исправлено!")
            print("Логин: director")
            print("Пароль: director123")
            
        except Exception as e:
            print(f"Ошибка: {e}")
            db.session.rollback()

if __name__ == '__main__':
    fix_passwords()
