from flask import Flask, render_template, redirect, url_for, request, flash, jsonify, send_file, make_response, session
import uuid
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from models import (db, User, Role, Product, Order, ProductionTask, FinancialTransaction, InventoryItem, 
                   SupplierOrder, Notification, Company, Resource, ResourceRequest, CustomOrder, OrderItem,
                   SalaryPayment, PaymentMethod, Client, Contract, ExpenseCategory, Budget, InventoryTransaction,
                   QualityControl, MaintenanceRecord, Report)
from functools import wraps
import os, io, csv, random, string
from datetime import datetime, timedelta
from openpyxl import Workbook

def create_app(config_name=None):
    app = Flask(__name__, static_folder='static', template_folder='templates')
    
    # Загружаем конфигурацию
    if config_name is None:
        config_name = os.environ.get('FLASK_ENV', 'development')
    
    try:
        from config import config
        app.config.from_object(config[config_name])
    except ImportError:
        # Fallback к старой конфигурации
        app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY') or 'dev-change-this-secret'
        app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL') or 'sqlite:///crm.db'
        app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    db.init_app(app)

    login_manager = LoginManager()
    login_manager.login_view = 'login'
    login_manager.init_app(app)

    @login_manager.user_loader
    def load_user(user_id):
        try:
            return User.query.get(int(user_id))
        except Exception:
            return None

    def role_required(roles):
        if isinstance(roles, str):
            roles = [roles]
        def decorator(f):
            @wraps(f)
            @login_required
            def decorated_function(*args, **kwargs):
                if not any(current_user.has_role(r) for r in roles):
                    flash('У вас нет доступа к этой странице', 'danger')
                    return redirect(url_for('login'))
                return f(*args, **kwargs)
            return decorated_function
        return decorator

    @app.route('/')
    def index():
        if current_user.is_authenticated:
            if current_user.has_role('director'):
                return redirect(url_for('director_dashboard'))
            elif current_user.has_role('manager'):
                return redirect(url_for('manager_dashboard'))
            elif current_user.has_role('supplier'):
                return redirect(url_for('supplier_dashboard'))
            elif current_user.has_role('warehouse'):
                return redirect(url_for('warehouse_dashboard'))
            elif current_user.has_role('production'):
                return redirect(url_for('production_dashboard'))
            elif current_user.has_role('accountant'):
                return redirect(url_for('accountant_dashboard'))
        return redirect(url_for('login'))

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            username = request.form['username']
            password = request.form['password']
            user = User.query.filter_by(username=username).first()
            
            if user and user.check_password(password):
                login_user(user)
                flash('Успешный вход в систему!', 'success')
                return redirect(url_for('index'))
            else:
                flash('Неверное имя пользователя или пароль', 'danger')
        
        return render_template('login.html')

    @app.route('/logout')
    @login_required
    def logout():
        logout_user()
        flash('Вы вышли из системы', 'info')
        return redirect(url_for('login'))

    # Директор
    @app.route('/director')
    @role_required('director')
    def director_dashboard():
        return render_template('director.html')

    @app.route('/director/company-settings')
    @role_required('director')
    def director_company_settings():
        return render_template('director_company_settings.html')

    # Менеджер
    @app.route('/manager')
    @role_required('manager')
    def manager_dashboard():
        return render_template('manager.html')

    # Поставщик
    @app.route('/supplier')
    @role_required('supplier')
    def supplier_dashboard():
        return render_template('supplier.html')

    @app.route('/supplier/contracts')
    @role_required('supplier')
    def supplier_contracts():
        return render_template('supplier_contracts.html')

    @app.route('/supplier/quality-control')
    @role_required('supplier')
    def supplier_quality_control():
        return render_template('supplier_quality_control.html')

    @app.route('/supplier/emergency-orders')
    @role_required('supplier')
    def supplier_emergency_orders():
        return render_template('supplier_emergency_orders.html')

    @app.route('/supplier/budget-management')
    @role_required('supplier')
    def supplier_budget_management():
        return render_template('supplier_budget_management.html')

    @app.route('/supplier/recommendations')
    @role_required('supplier')
    def supplier_recommendations():
        return render_template('supplier_recommendations.html')

    @app.route('/supplier/reports')
    @role_required('supplier')
    def supplier_reports():
        return render_template('supplier_reports.html')

    # Склад
    @app.route('/warehouse')
    @role_required('warehouse')
    def warehouse_dashboard():
        return render_template('warehouse.html')

    @app.route('/warehouse/stock-alerts')
    @role_required('warehouse')
    def warehouse_stock_alerts():
        return render_template('warehouse.html')

    @app.route('/warehouse/analytics')
    @role_required('warehouse')
    def warehouse_analytics():
        return render_template('warehouse.html')

    @app.route('/warehouse/supplier-performance')
    @role_required('warehouse')
    def warehouse_supplier_performance():
        return render_template('warehouse.html')

    @app.route('/warehouse/automated-reordering')
    @role_required('warehouse')
    def warehouse_automated_reordering():
        return render_template('warehouse_automated_reordering.html')

    @app.route('/warehouse/barcode-scanner')
    @role_required('warehouse')
    def warehouse_barcode_scanner():
        return render_template('warehouse_barcode_scanner.html')

    @app.route('/warehouse/cycle-counting')
    @role_required('warehouse')
    def warehouse_cycle_counting():
        return render_template('warehouse_cycle_counting.html')

    @app.route('/warehouse/expected-deliveries')
    @role_required('warehouse')
    def warehouse_expected_deliveries():
        return render_template('warehouse_expected_deliveries.html')

    @app.route('/warehouse/quality-inspection')
    @role_required('warehouse')
    def warehouse_quality_inspection():
        return render_template('warehouse_quality_inspection.html')

    @app.route('/warehouse/reports')
    @role_required('warehouse')
    def warehouse_reports():
        return render_template('warehouse_reports.html')

    @app.route('/warehouse/zones')
    @role_required('warehouse')
    def warehouse_zones():
        return render_template('warehouse_zones.html')

    # Производство
    @app.route('/production')
    @role_required('production')
    def production_dashboard():
        return render_template('production.html')

    @app.route('/production/planning')
    @role_required('production')
    def production_planning():
        return render_template('production_planning.html')

    @app.route('/production/equipment-management')
    @role_required('production')
    def production_equipment_management():
        return render_template('production_equipment_management.html')

    @app.route('/production/material-requirements')
    @role_required('production')
    def production_material_requirements():
        return render_template('production_material_requirements.html')

    @app.route('/production/check-materials')
    @role_required('production')
    def production_check_materials():
        return render_template('production_check_materials.html')

    @app.route('/production/worker-productivity')
    @role_required('production')
    def production_worker_productivity():
        return render_template('production_worker_productivity.html')

    @app.route('/production/safety-compliance')
    @role_required('production')
    def production_safety_compliance():
        return render_template('production_safety_compliance.html')

    @app.route('/production/reports')
    @role_required('production')
    def production_reports():
        return render_template('production_reports.html')

    # Бухгалтер
    @app.route('/accountant')
    @role_required('accountant')
    def accountant_dashboard():
        return render_template('accountant.html')

    @app.route('/accountant/invoice-management')
    @role_required('accountant')
    def accountant_invoice_management():
        return render_template('accountant_invoice_management.html')

    @app.route('/accountant/payroll-management')
    @role_required('accountant')
    def accountant_payroll_management():
        return render_template('accountant_payroll_management.html')

    @app.route('/accountant/tax-management')
    @role_required('accountant')
    def accountant_tax_management():
        return render_template('accountant_tax_management.html')

    @app.route('/accountant/budget-planning')
    @role_required('accountant')
    def accountant_budget_planning():
        return render_template('accountant_budget_planning.html')

    @app.route('/accountant/cash-flow')
    @role_required('accountant')
    def accountant_cash_flow():
        return render_template('accountant_cash_flow.html')

    @app.route('/accountant/financial-analysis')
    @role_required('accountant')
    def accountant_financial_analysis():
        return render_template('accountant_financial_analysis.html')

    @app.route('/accountant/asset-management')
    @role_required('accountant')
    def accountant_asset_management():
        return render_template('accountant_asset_management.html')

    @app.route('/accountant/expense-approval')
    @role_required('accountant')
    def accountant_expense_approval():
        return render_template('accountant_expense_approval.html')

    @app.route('/accountant/audit-trail')
    @role_required('accountant')
    def accountant_audit_trail():
        return render_template('accountant_audit_trail.html')

    @app.route('/accountant/compliance')
    @role_required('accountant')
    def accountant_compliance():
        return render_template('accountant_compliance.html')

    # Калькуляторы
    @app.route('/itp-calculator')
    @login_required
    def itp_calculator():
        return render_template('itp_calculator.html')

    @app.route('/gvs-calculator')
    @login_required
    def gvs_calculator():
        return render_template('gvs_calculator.html')

    # Центр аккаунта
    @app.route('/account')
    @login_required
    def account_center():
        return render_template('account_center.html')

    @app.route('/change-password', methods=['GET', 'POST'])
    @login_required
    def change_password():
        if request.method == 'POST':
            current_password = request.form['current_password']
            new_password = request.form['new_password']
            confirm_password = request.form['confirm_password']
            
            if not current_user.check_password(current_password):
                flash('Текущий пароль неверен', 'danger')
                return render_template('change_password.html')
            
            if new_password != confirm_password:
                flash('Новые пароли не совпадают', 'danger')
                return render_template('change_password.html')
            
            current_user.set_password(new_password)
            db.session.commit()
            flash('Пароль успешно изменен', 'success')
            return redirect(url_for('account_center'))
        
        return render_template('change_password.html')

    # Обработчики ошибок
    @app.errorhandler(404)
    def not_found(error):
        return render_template('404.html'), 404

    @app.errorhandler(500)
    def internal_error(error):
        return render_template('500.html'), 500

    return app

if __name__ == '__main__':
    app = create_app()
    with app.app_context():
        db.create_all()
    app.run(debug=True)
